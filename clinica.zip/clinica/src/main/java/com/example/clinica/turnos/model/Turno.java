package com.example.clinica.turnos.model;
import com.example.clinica.odontologos.model.Odontologo;
import com.example.clinica.pacientes.model.Paciente;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Time;
@Entity
@Getter
@Setter
public class Turno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_t;


    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.MERGE)
    @JoinColumn(referencedColumnName = "id")
    private Odontologo odontologo;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.MERGE)
    @JoinColumn(referencedColumnName = "id")
    private Paciente paciente;

    @Column
    private Date fecha;
    @Column
    private Time hora;

    public Turno(){}
}
