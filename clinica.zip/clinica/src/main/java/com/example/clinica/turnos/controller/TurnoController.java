package com.example.clinica.turnos.controller;

import com.example.clinica.turnos.dto.TurnoDTO;
import com.example.clinica.turnos.model.Turno;
import com.example.clinica.turnos.service.TurnoService;
import com.sun.istack.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

@RestController
@RequestMapping("turnos")
public class TurnoController {

    @Autowired
    private TurnoService turnoService;

    @PostMapping("/guardar")
    public ResponseEntity<TurnoDTO> guardar(@NotNull @RequestBody TurnoDTO turnoDTO){
        return ResponseEntity.ok(turnoService.guardar(turnoDTO));
    }

    @GetMapping("/traerTodos")
    public ResponseEntity<List<TurnoDTO>> traerTodos(){
        return ResponseEntity.ok(turnoService.buscarTodos());
    }

    @GetMapping("/traerId/{id}")
    public ResponseEntity<TurnoDTO> traer(@PathVariable Integer id){
        return ResponseEntity.ok(turnoService.buscarId(id));
    }

    @DeleteMapping("/borrarId/{id}")
    public void borrar(@PathVariable Integer id){
        turnoService.eliminar(id);
    }
}
