package com.example.clinica.odontologos.service.crudi;

import java.util.List;

public interface crudi <T>{

    public T guardar(T t);
    public T buscarId(Integer id) throws Exception;
    public List<T> buscarTodos();
    public void eliminar(Integer id);

}