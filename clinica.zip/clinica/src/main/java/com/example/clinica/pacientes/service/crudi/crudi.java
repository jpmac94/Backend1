package com.example.clinica.pacientes.service.crudi;

import java.util.List;

public interface crudi <T>{

    public T guardar(T t);
    public T buscarId(Integer id);
    public List<T> buscarTodos();
    public void eliminar(Integer id);

}