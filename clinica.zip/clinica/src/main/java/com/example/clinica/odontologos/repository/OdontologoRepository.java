package com.example.clinica.odontologos.repository;

import com.example.clinica.odontologos.model.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
public interface OdontologoRepository extends JpaRepository<Odontologo,Integer> {
}
