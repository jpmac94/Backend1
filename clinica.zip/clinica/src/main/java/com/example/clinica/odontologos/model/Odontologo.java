package com.example.clinica.odontologos.model;

import com.example.clinica.turnos.model.Turno;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
public class Odontologo {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    @Column
    private String nombre;
    @Column
    private String apellido;
    @Column
    private String matricula;

    @OneToMany(mappedBy = "odontologo",fetch = FetchType.LAZY,cascade = CascadeType.MERGE,orphanRemoval = true)
    @JsonIgnore
    private Set<Turno> turnos=new HashSet<>();



    public Odontologo(){}
}
