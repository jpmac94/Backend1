package com.example.clinica.pacientes.dto;

import com.example.clinica.pacientes.model.Domicilio;
import com.example.clinica.turnos.model.Turno;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
public class PacienteDTO {

    private Integer id;

    private String nombre;
    private String apellido;
    private String dni;
    private Date fecha;

    private Domicilio domicilio;

    private Set<Turno> turno=new HashSet<>();

    public PacienteDTO(){}

}
