package com.example.clinica.pacientes.service;

import com.example.clinica.pacientes.dto.PacienteDTO;
import com.example.clinica.pacientes.model.Paciente;
import com.example.clinica.pacientes.repository.PacienteRepository;
import com.example.clinica.pacientes.service.crudi.crudiPacientes;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PacienteService implements crudiPacientes {
    @Autowired
    private PacienteRepository pacienteRepository;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public PacienteDTO guardar(PacienteDTO pacienteDTO){
       Paciente paciente=pacienteRepository.save(dto_entity(pacienteDTO));
        return entity_dto(paciente);

    }

    @Override
    public PacienteDTO buscarId(Integer id) {
        if (pacienteRepository.existsById(id)){
            return entity_dto(pacienteRepository.findById(id).get());
        }
        return null;
    }

    @Override
    public List<PacienteDTO> buscarTodos() {
        return pacienteRepository.findAll().stream().map(paciente -> entity_dto(paciente)).collect(Collectors.toList());
    }

    @Override
    public void eliminar(Integer id) {
        if (pacienteRepository.existsById(id)){
            pacienteRepository.deleteById(id);
        }
    }

    public PacienteDTO entity_dto(Paciente paciente){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(paciente,PacienteDTO.class);
    }

    public Paciente dto_entity(PacienteDTO pacienteDTO){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(pacienteDTO,Paciente.class);
    }
}
