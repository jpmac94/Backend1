package com.example.clinica.odontologos.controller;

import com.example.clinica.odontologos.dto.OdontologoDTO;
import com.example.clinica.odontologos.service.OdontologoService;
import com.sun.istack.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("odontologo")
public class OdontologoController {

    @Autowired
    private OdontologoService odontologoService;

    @PostMapping("/guardar")
    public ResponseEntity<OdontologoDTO> guardar(@RequestBody @NotNull @Valid OdontologoDTO odontologoDTO){
        return ResponseEntity.ok(odontologoService.guardar(odontologoDTO));
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<?> buscarId(@NotNull @PathVariable Integer id){
        if (odontologoService.buscarId(id)!=null) {
            return new ResponseEntity<OdontologoDTO>(odontologoService.buscarId(id), HttpStatus.OK);
        }else{
            return new ResponseEntity<String>("no esta en la lista",HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/buscarTodos")
    public ResponseEntity<List<OdontologoDTO>> traerTodos(){
        return ResponseEntity.ok(odontologoService.buscarTodos());
    }

    @DeleteMapping("/borrarId/{id}")
    public void borrar(@PathVariable Integer id){
        odontologoService.eliminar(id);
    }

}
