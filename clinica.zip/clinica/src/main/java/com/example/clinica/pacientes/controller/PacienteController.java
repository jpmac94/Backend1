package com.example.clinica.pacientes.controller;

import com.example.clinica.pacientes.dto.PacienteDTO;
import com.example.clinica.pacientes.model.Paciente;
import com.example.clinica.pacientes.service.PacienteService;
import com.sun.istack.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("paciente")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @PostMapping("/guardar")
    public ResponseEntity<PacienteDTO> guerdar(@NotNull @RequestBody PacienteDTO pacienteDTO){
       return ResponseEntity.ok(pacienteService.guardar(pacienteDTO));
    }

    @GetMapping("/traerTodos")
    public ResponseEntity<List<PacienteDTO>> traerTodos(){
        return ResponseEntity.ok(pacienteService.buscarTodos());
    }

    @GetMapping("/traerId/{id}")
    public ResponseEntity<PacienteDTO> traerId(@PathVariable Integer id){
        return ResponseEntity.ok(pacienteService.buscarId(id));
    }

    @DeleteMapping("/borrarId/{id}")
    public void borrar(@PathVariable Integer id){
        pacienteService.eliminar(id);
    }

}
