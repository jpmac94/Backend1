package com.example.clinica.turnos.service;

import com.example.clinica.turnos.dto.TurnoDTO;
import com.example.clinica.turnos.model.Turno;
import com.example.clinica.turnos.repository.TurnoRepository;
import com.example.clinica.turnos.service.crudI.crudiTurnos;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TurnoService implements crudiTurnos {

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private TurnoRepository turnoRepository;

    @Override
    public TurnoDTO guardar(TurnoDTO turnoDTO){
    Turno turno=turnoRepository.save(dto_entity(turnoDTO));
    return entity_dto(turno);
    }

    @Override
    public TurnoDTO buscarId(Integer id) {
        if (turnoRepository.existsById(id)){
            return entity_dto(turnoRepository.findById(id).get());
        }
        return null;
    }

    @Override
    public List<TurnoDTO> buscarTodos() {

        return turnoRepository.findAll().stream().map(turno -> entity_dto(turno)).collect(Collectors.toList());
    }

    @Override
    public void eliminar(Integer id) {
        if (turnoRepository.existsById(id)){
            turnoRepository.deleteById(id);
        }
    }

    public Turno dto_entity(TurnoDTO turnoDTO){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(turnoDTO,Turno.class);
    }

    public TurnoDTO entity_dto(Turno turno){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(turno,TurnoDTO.class);
    }
}
