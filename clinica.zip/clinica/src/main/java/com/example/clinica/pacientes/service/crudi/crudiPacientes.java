package com.example.clinica.pacientes.service.crudi;

import com.example.clinica.pacientes.dto.PacienteDTO;

public interface crudiPacientes extends crudi<PacienteDTO>{
}
