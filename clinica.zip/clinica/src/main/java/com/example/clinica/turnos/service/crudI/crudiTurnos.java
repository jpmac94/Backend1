package com.example.clinica.turnos.service.crudI;

import com.example.clinica.turnos.dto.TurnoDTO;

public interface crudiTurnos extends crudi<TurnoDTO>{
}
