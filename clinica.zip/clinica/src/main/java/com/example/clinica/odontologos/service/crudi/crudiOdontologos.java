package com.example.clinica.odontologos.service.crudi;

import com.example.clinica.odontologos.dto.OdontologoDTO;

public interface crudiOdontologos extends crudi<OdontologoDTO>{
}
