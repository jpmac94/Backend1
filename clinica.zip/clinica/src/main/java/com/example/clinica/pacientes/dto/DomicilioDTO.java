package com.example.clinica.pacientes.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DomicilioDTO {

    private String calle;
    private String nro;
    private String localidad;
    private String provincia;

    public DomicilioDTO(){}

}
