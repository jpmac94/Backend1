package com.example.clinica.pacientes.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class Domicilio {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;
    @Column
    private String calle;
    @Column
    private String nro;
    @Column
    private String localidad;
    @Column
    private String provincia;

    public Domicilio(){}

}
