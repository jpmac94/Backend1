package com.example.clinica.turnos.dto;


import com.example.clinica.odontologos.model.Odontologo;
import com.example.clinica.pacientes.model.Paciente;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.sql.Time;

@Getter
@Setter
public class TurnoDTO {

    private Paciente paciente;
    private Odontologo odontologo;
    private Date fecha;
    private Time hora;

    public TurnoDTO(){}
}
