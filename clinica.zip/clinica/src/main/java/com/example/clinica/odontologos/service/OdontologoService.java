package com.example.clinica.odontologos.service;

import com.example.clinica.odontologos.dto.OdontologoDTO;
import com.example.clinica.odontologos.model.Odontologo;
import com.example.clinica.odontologos.repository.OdontologoRepository;
import com.example.clinica.odontologos.service.crudi.crudiOdontologos;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class OdontologoService implements crudiOdontologos{
    @Autowired
    private OdontologoRepository odontologoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public OdontologoDTO guardar(OdontologoDTO odontologoDTO){
        Odontologo odontologo=dto_entity(odontologoDTO);
        OdontologoDTO odontologoDTO1=entity_dto(odontologoRepository.save(odontologo));
        return odontologoDTO1;
    }

    @Override
    public OdontologoDTO buscarId(Integer id) {
    if (odontologoRepository.existsById(id)){
        return entity_dto(odontologoRepository.findById(id).get());
    }
    return null;
    }

    @Override
    public List<OdontologoDTO> buscarTodos() {
        return odontologoRepository.findAll().stream().map(odontologo -> entity_dto(odontologo)).collect(Collectors.toList());
    }

    @Override
    public void eliminar(Integer id) {
        if (odontologoRepository.existsById(id)){
           odontologoRepository.deleteById(id);
        }
    }


    public OdontologoDTO entity_dto(Odontologo odontologo){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(odontologo,OdontologoDTO.class);
    }

    public Odontologo dto_entity(OdontologoDTO odontologoDTO){
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper.convertValue(odontologoDTO,Odontologo.class);
    }
}

